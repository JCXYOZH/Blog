**<center>图书管理程序设计文档</center>**
<br>


**题目要求**

学生独立完成设计与实现<br>
实现一个美观实用的命令行界面<br>
完成图书管理功能，包括添加图书、修改图书、查询图书和显示所有图书信息<br>
保持良好的程序格式和代码风格<br>

**技术方法**

语言：Java <br>
数据结构：数组和 ArrayList <br>
用户界面：命令行界面（Console）<br>
输入处理：Scanner类<br>
异常处理：try-catch语句和自定义异常<br>

**类和功能**

*Book类*

该类表示图书对象，包含以下属性和方法：<br>
　属性：<br>
　　bookId：图书编号<br>
　　bookName：图书名称<br>
方法：<br>
　　构造方法：初始化图书编号和图书名称<br>
　　getBookId()：获取图书编号<br>
　　setBookId()：设置图书编号<br>
　　getBookName()：获取图书名称<br>
　　setBookName()：设置图书名称<br>

*Library类*

该类表示图书馆对象，包含以下属性和方法：<br>
　属性：<br>
    books：存放图书信息的集合（ArrayList<Book>类型）<br>
　方法：<br>
    构造方法：初始化books集合<br>
    addBook(int bookId, String bookName)：添加图书<br>
    modifyBook(int bookId, String newBookName)：修改图书<br>
    queryBook(int bookId)：查询图书<br>
    displayAllBooks()：显示所有图书信息<br>
    isBookIdDuplicate(int bookId)：检查图书编号是否重复<br>
    findBookById(int bookId)：根据图书编号查找图书<br>

*Main类*

该类包含程序的入口点main方法，实现了图书管理程序的主要逻辑：<br>
　创建Library对象和Scanner对象<br>
　显示菜单，接受用户输入，并根据选择执行相应的操作<br>
　根据用户选择调用Library类的对应方法<br>
　处理异常情况，并提供错误信息提示<br>
　循环执行，直到用户选择退出程序为止