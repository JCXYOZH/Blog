package com.lzh.library;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        int choice = 0;
        do {
            System.out.println("******** 图书管理系统 ********");
            System.out.println("1、添加图书");
            System.out.println("2、修改图书");
            System.out.println("3、查询图书");
            System.out.println("4、显示所有图书信息");
            System.out.println("0、退出");
            System.out.print("请选择功能：");

            try {
                choice = scanner.nextInt();
                scanner.nextLine(); // 读取换行符
            } catch (InputMismatchException e) {
                System.out.println("输入无效，请重新输入！");
                scanner.nextLine(); // 清空输入缓冲区，避免无限循环读取错误输入
            }

            switch (choice) {
                case 1:
                    System.out.print("请输入图书编号：");
                    int bookId = scanner.nextInt();
                    scanner.nextLine(); // 读取换行符
                    System.out.print("请输入图书名称：");
                    String bookName = scanner.nextLine();
                    try {
                        library.addBook(bookId, bookName);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    System.out.print("请输入要修改的图书编号：");
                    int modifyBookId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("请输入新的图书名称：");
                    String newBookName = scanner.nextLine();
                    try {
                        library.modifyBook(modifyBookId, newBookName);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.print("请输入要查询的图书编号：");
                    int queryBookId = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        library.queryBook(queryBookId);
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    library.displayAllBooks();
                    break;
                case 0:
                    System.out.println("程序已退出。");
                    break;
                default:
                    System.out.println("无效的选择，请重新输入！");
                    break;
            }
        } while (choice != 0);

        scanner.close();
    }
}
