package com.lzh.library;

import java.util.ArrayList;
import java.util.List;

public class Library {
    // books为泛型List，为存储Book类型的元素
    private List<Book> books;

    public Library() {
        // 创建ArrayList实例，使之只能存储Book类型的对象
        this.books = new ArrayList<>(); // 使用泛型List<Book>
    }

    // 添加图书
    public void addBook(int bookId, String bookName) {
        Book book = new Book(bookId, bookName);

        // 检查图书编号是否重复
        if (isBookIdDuplicate(bookId)) {
            throw new IllegalArgumentException("图书编号已存在，请重新输入！");
        }

        // 检查图书名称是否为空
        if (bookName.isEmpty()) {
            throw new IllegalArgumentException("图书名称不能为空，请重新输入！");
        }

        books.add(book);
        System.out.println("图书添加成功！");
    }

    // 修改图书
    public void modifyBook(int bookId, String newBookName) {
        // 检查图书编号是否存在
        Book book = findBookById(bookId);
        if (book == null) {
            throw new IllegalArgumentException("图书编号不存在，请重新输入！");
        }

        // 检查图书名称是否为空
        if (newBookName.isEmpty()) {
            throw new IllegalArgumentException("图书名称不能为空，请重新输入！");
        }

        book.setBookName(newBookName);
        System.out.println("图书修改成功！");
    }

    // 查询图书
    public void queryBook(int bookId) {
        // 检查图书编号是否存在
        Book book = findBookById(bookId);
        if (book == null) {
            throw new IllegalArgumentException("图书编号不存在，请重新输入！");
        }

        System.out.println("图书编号：" + book.getBookId());
        System.out.println("图书名称：" + book.getBookName());
    }

    // 显示所有图书信息
    public void displayAllBooks() {
        if (books.isEmpty()) {
            System.out.println("图书馆为空！");
            return;
        }

        System.out.println("图书信息：");
        for (Book book : books) {
            System.out.println("图书编号：" + book.getBookId());
            System.out.println("图书名称：" + book.getBookName());
            System.out.println("--------------------------");
        }
    }

    // 检查图书编号是否重复
    private boolean isBookIdDuplicate(int bookId) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return true;
            }
        }
        return false;
    }

    // 根据图书编号查找图书
    private Book findBookById(int bookId) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return book;
            }
        }
        return null;
    }
}
