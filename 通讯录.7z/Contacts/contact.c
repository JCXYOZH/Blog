#include "contact.h"

void InitContact(struct Contact *ps)
{
    ps -> data = (struct PeoInfo*)malloc(DEFAULT_SZ * sizeof (struct PeoInfo));
    if (ps -> data == NULL)
    {
        return;
    }
    ps -> size = 0;
    ps -> capacity = DEFAULT_SZ;
    LoadContact(ps);
}

void CheckCapacity(struct Contact *ps)
{
    if (ps -> size == ps -> capacity)
    {
        struct PeoInfo* ptr = realloc(ps -> data, (ps -> capacity + 2) * sizeof(struct PeoInfo));
        if (ptr != NULL)
        {
            ps -> data = ptr;
            ps -> capacity += 2;
            printf("klcg\n");
        }
        else
        {
            printf("klsb\n");
        }
    }
}

void AddContact(struct Contact *ps)
{
    CheckCapacity(ps);
    printf("xm:");
    scanf("%s", ps -> data[ps -> size].name);
    printf("ll:");
    scanf("%d", &(ps -> data[ps -> size].age));
    printf("xb:");
    scanf("%s", ps -> data[ps -> size].sex);
    printf("dh:");
    scanf("%s", ps -> data[ps -> size].tele);
    printf("dz:");
    scanf("%s", ps -> data[ps -> size].addr);
    ps -> size++;
    printf("tjcg\n");
}

void ShowContact(const struct Contact *ps)
{
    if (ps -> size == 0)
    {
        printf("txlwk\n");
    }
    else
    {
        printf("%-20s\t%-4s\t%-5s\t%-12s\t%-20s\n", "xm", "ll", "xb", "dh", "dz");
        for (int i = 0; i < ps->size; i++)
        {
            printf("%-20s\t%-4d\t%-5s\t%-12s\t%-20s\n",
                   ps -> data[i].name,
                   ps -> data[i].age,
                   ps -> data[i].sex,
                   ps -> data[i].tele,
                   ps -> data[i].addr);
        }
    }
}

static int FindByName(const struct Contact *ps, char name[MAX_NAME])
{
    for (int i = 0; i < ps->size; i++)
    {
        if (strcmp(ps -> data[i].name, name) == 0)
        {
            return i;
        }
    }
    return -1;
}

void DelContact(struct Contact *ps)
{
    int pos = 0;
    char name[MAX_NAME];
    printf("scdx:");
    scanf("%s", name);
    pos = FindByName(ps, name);
    if (pos == -1)
    {
        printf("bcz\n");
    }
    else
    {
        int j = 0;
        for (j = pos; j < ps->size - 1; j++)
        {
            ps -> data[j] = ps -> data[j + 1];
        }
        ps -> size--;
        printf("sccg\n");
    }
}

void SearchContact(const struct Contact *ps)
{
    int pos = 0;
    char name[MAX_NAME];
    printf("czdx:");
    scanf("%s", name);
    pos = FindByName(ps, name);
    if (pos == -1)
    {
        printf("bcz\n");
    }
    else
    {
        printf("%-20s\t%-4s\t%-5s\t%-12s\t%-20s\n", "xm", "ll", "xb", "dh", "dz");
        printf("%-20s\t%-4d\t%-5s\t%-12s\t%-20s\n",
               ps -> data[pos].name,
               ps -> data[pos].age,
               ps -> data[pos].sex,
               ps -> data[pos].tele,
               ps -> data[pos].addr);
    }
}

void ModifyContact(struct Contact *ps)
{
    int pos = 0;
    char name[MAX_NAME];
    printf("xgdx:");
    scanf("%s", name);
    pos = FindByName(ps, name);
    if (pos == -1)
    {
        printf("bcz\n");
    }
    else
    {
        printf("xm:");
        scanf("%s", ps -> data[pos].name);
        printf("ll:");
        scanf("%d", &(ps -> data[pos].age));
        printf("xb:");
        scanf("%s", ps -> data[pos].sex);
        printf("dh:");
        scanf("%s", ps -> data[pos].tele);
        printf("dz:");
        scanf("%s", ps -> data[pos].addr);
        printf("xgwc\n");
    }
}

void SortContact(struct Contact *ps)
{
    ;
}

void DestroyContact(Contact *ps)
{
    free(ps -> data);
    ps -> data = NULL;
}

void SaveContact(Contact *ps)
{
    FILE *pfWrite = fopen("contat.txt", "wb");
    if (pfWrite == NULL)
    {
        printf("%s\n", strerror(errno));
        return;
    }
    for (int i = 0; i < ps->size; i++)
    {
        fwrite(&(ps -> data[i]), sizeof(PeoInfo), 1, pfWrite);
    }
    fclose(pfWrite);
    pfWrite = NULL;
}

void LoadContact(Contact *ps)
{
    PeoInfo tmp = {0};
    FILE *pfRead = fopen("contact.txt", "rb");
    if (pfRead == NULL)
    {
        printf("SaveContact::%s\n", strerror(errno));
        return;
    }
    while (fread(&tmp, sizeof(PeoInfo), 1, pfRead))
    {
        CheckCapacity(ps);
        ps -> data[ps -> size] = tmp;
        ps -> size++;
    }
    fclose(pfRead);
    pfRead = NULL;
}