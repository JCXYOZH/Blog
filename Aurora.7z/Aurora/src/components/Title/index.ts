export { default as MainTitle } from './src/MainTitle.vue'
export { default as SubTitle } from './src/SubTitle.vue'
