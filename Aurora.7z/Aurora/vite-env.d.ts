// vite-env.d.ts
/// <reference types="vite-plugin-pages/client" />
